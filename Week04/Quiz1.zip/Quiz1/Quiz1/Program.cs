﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Quiz1
{
    class Program
    {
        static void Main(string[] args)
        {
            double pounds;
            double ounces;
            double grams;
            double kilogram;
            string userInput;

            Console.WriteLine("Please enter weight in pounds and ounces.");
            Console.WriteLine("pounds?");
            userInput = Console.ReadLine();
            pounds = Convert.ToDouble(userInput);
            Console.WriteLine("ounces?");
            userInput = Console.ReadLine();
            ounces = Convert.ToDouble(userInput);

            pounds = pounds + ounces / 16;
            grams = pounds * 443.592 ;
            kilogram = grams/1000;       
            kilogram = Convert.ToInt32(kilogram);
            grams = kilogram * 1000 - grams;
            grams = Convert.ToInt32(grams);
            
            Console.WriteLine($"{pounds}lb {ounces}oz is {kilogram}kg {grams}g");


            
        }
    }
}
